import { MongoClient } from "mongodb";
import dotenv from "dotenv";
dotenv.config


/*const variable = process.env.MONGO_CONN_STRING
console.log(variable);*/

const connectionString = "mongodb+srv://st10084600:Nikhil1663@cluster0.1nunp7l.mongodb.net/";

const client = new MongoClient(connectionString);

let conn;
try {
  conn = await client.connect();
  console.log("successfully connected to Db")
} catch(e) {
  console.error(e);
}


let db = conn.db("apds");

export default db;